exec /usr/local/bin/eleris-shell
