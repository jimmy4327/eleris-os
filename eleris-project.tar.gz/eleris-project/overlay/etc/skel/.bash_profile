[ -f ~/.bashrc ] && . ~/.bashrc
# On the first console (tty1), start the Eleris desktop. If it exits, you get a normal shell.
if [ -z "${DISPLAY:-}" ] && [ "$(tty)" = "/dev/tty1" ]; then
  startx
fi
