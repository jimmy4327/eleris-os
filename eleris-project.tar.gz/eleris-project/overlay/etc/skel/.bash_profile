[ -f ~/.bashrc ] && . ~/.bashrc
# On the first console (tty1), start the Eleris desktop.
# If it exits or crashes, you land in a normal shell so you can read the error.
if [ -z "${WAYLAND_DISPLAY:-}" ] && [ "$(tty)" = "/dev/tty1" ]; then
  cage -s -- /usr/local/bin/eleris-shell
fi
