#!/usr/bin/env bash
# Builds eleria-os.iso. Run inside a Debian 12 (bookworm) VM, as root:  ./build.sh
set -euo pipefail
[ "$(id -u)" -eq 0 ] || { echo "Run as root (use: su -)."; exit 1; }
grep -q 'VERSION_CODENAME=bookworm' /etc/os-release || { echo "This script expects Debian 12 (bookworm)."; exit 1; }

HERE="$(cd "$(dirname "$0")" && pwd)"
WORK=/var/tmp/eleria-build

apt-get update
apt-get install -y live-build debootstrap squashfs-tools xorriso mtools dosfstools \
  syslinux syslinux-common isolinux grub-pc-bin grub-efi-amd64-bin

rm -rf "$WORK"; mkdir -p "$WORK"; cd "$WORK"

lb config \
  --distribution bookworm \
  --architectures amd64 \
  --binary-images iso-hybrid \
  --bootloaders "syslinux,grub-efi" \
  --debian-installer live \
  --archive-areas "main contrib non-free-firmware" \
  --memtest none \
  --iso-application "Eleria OS" \
  --iso-publisher "Eleria" \
  --iso-volume "ELERIA_1" \
  --bootappend-live "boot=live components quiet username=eleria hostname=eleria"

mkdir -p config/includes.chroot config/package-lists config/hooks/normal
cp -a "$HERE/overlay/." config/includes.chroot/
cp "$HERE/packages.list" config/package-lists/eleria.list.chroot
mkdir -p config/archives
cp "$HERE"/archives/* config/archives/
cp "$HERE/hook.chroot" config/hooks/normal/9000-eleria.hook.chroot
chmod +x config/hooks/normal/9000-eleria.hook.chroot
cp "$HERE/hook.binary" config/hooks/normal/9100-eleria.hook.binary
chmod +x config/hooks/normal/9100-eleria.hook.binary

lb build 2>&1 | tee "$HERE/build.log"

ISO="$(ls -1 "$WORK"/*.iso | head -n1)"
cp "$ISO" "$HERE/eleria-os.iso"
chown --reference="$HERE" "$HERE/eleria-os.iso" "$HERE/build.log" 2>/dev/null || true
echo; echo "Done: $HERE/eleria-os.iso ($(du -h "$HERE/eleria-os.iso" | cut -f1))"
