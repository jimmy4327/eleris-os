[ -f ~/.bashrc ] && . ~/.bashrc
# On the first console (tty1), start the Eleria desktop. When it ends (for example on Log Out),
# end this session too, so the next login starts again at the Eleria login screen.
# For a normal text login use another console (Ctrl+Alt+F2).
if [ -z "${DISPLAY:-}" ] && [ "$(tty)" = "/dev/tty1" ]; then
  startx
  sleep 3
  exit
fi
