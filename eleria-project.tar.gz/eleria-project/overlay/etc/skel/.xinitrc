exec /usr/local/bin/eleria-shell
