addEventListener('keydown',function(e){if(/^F([1-9]|1[0-2])$/.test(e.key)||((e.ctrlKey||e.metaKey)&&(e.key=='s'||e.key=='S'))){e.preventDefault();e.stopImmediatePropagation()}},true);
