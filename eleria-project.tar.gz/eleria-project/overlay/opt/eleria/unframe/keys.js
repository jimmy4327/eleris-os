addEventListener('keydown',function(e){if(/^F([1-9]|1[0-2])$/.test(e.key)){e.preventDefault();e.stopImmediatePropagation()}},true);
