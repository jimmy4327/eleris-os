addEventListener('keydown',function(e){var k=e.key,c=e.ctrlKey||e.metaKey;if(/^F([1-9]|1[0-2])$/.test(k)||(c&&/^[sSuU]$/.test(k))||(c&&e.shiftKey&&/^[ijcIJC]$/.test(k))){e.preventDefault();e.stopImmediatePropagation()}},true);
addEventListener('contextmenu',function(e){e.preventDefault()},true);
