# Packs the unframe extension into a signed .crx and registers it as an external Chromium extension.
import sys,os,zipfile,hashlib,struct,subprocess,json,io
src,out,extdir=sys.argv[1:4]
key=subprocess.check_output(['openssl','genrsa','2048'])
pub=subprocess.run(['openssl','rsa','-pubout','-outform','DER'],input=key,capture_output=True,check=True).stdout
buf=io.BytesIO()
with zipfile.ZipFile(buf,'w',zipfile.ZIP_DEFLATED) as z:
    for n in os.listdir(src):z.write(os.path.join(src,n),n)
zb=buf.getvalue();cid=hashlib.sha256(pub).digest()[:16]
def v(n):
    o=b''
    while True:
        c=n&127;n>>=7
        if n:o+=bytes([c|128])
        else:return o+bytes([c])
def f(t,d):return v(t<<3|2)+v(len(d))+d
sd=f(1,cid);msg=b'CRX3 SignedData\x00'+struct.pack('<I',len(sd))+sd+zb
open('/tmp/k.pem','wb').write(key);open('/tmp/m','wb').write(msg)
sig=subprocess.check_output(['openssl','dgst','-sha256','-sign','/tmp/k.pem','/tmp/m'])
hdr=f(2,f(1,pub)+f(2,sig))+f(10000,sd)
open(out,'wb').write(b'Cr24'+struct.pack('<II',3,len(hdr))+hdr+zb)
eid=''.join(chr(97+(c>>s&15)) for c in cid for s in(4,0))
os.makedirs(extdir,exist_ok=True)
json.dump({'external_crx':out,'external_version':'1.0'},open('%s/%s.json'%(extdir,eid),'w'))
print(eid)
